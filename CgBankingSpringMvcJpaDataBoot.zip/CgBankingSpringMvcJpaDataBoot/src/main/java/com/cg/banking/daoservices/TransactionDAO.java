package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.banking.beans.Transaction;
public interface TransactionDAO extends JpaRepository<Transaction, Integer>{


}
