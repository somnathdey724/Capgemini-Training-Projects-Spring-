package com.cg.banking.exceptions;

public class TransactionRollbackException extends Exception {

	private TransactionRollbackException() {
		super();
		// TODO Auto-generated constructor stub
	}

	private TransactionRollbackException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	private TransactionRollbackException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	private TransactionRollbackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	private TransactionRollbackException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
