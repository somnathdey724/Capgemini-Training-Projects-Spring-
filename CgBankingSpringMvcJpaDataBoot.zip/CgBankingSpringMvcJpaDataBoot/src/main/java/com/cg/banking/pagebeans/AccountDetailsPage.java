package com.cg.banking.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AccountDetailsPage {
	@FindBy(how=How.NAME,name="accountNo")
	private WebElement accountNo;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	
	public AccountDetailsPage() {}

	public String getAccountNo() {
		return accountNo.getAttribute("value");
	}

	public void setAccountNo(String accountNo) {
		this.accountNo.sendKeys(accountNo);
	}
	
	public void onClick() {
		submit.click();
	}
}
