package com.cg.banking.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class DepositPage {
	@FindBy(how=How.NAME,name="accountNo")
	private WebElement accountNo;
	@FindBy(how=How.NAME,name="accountBalance")
	private WebElement accountBalance;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;

	public DepositPage() {}

	public String getAccountNo() {
		return accountNo.getAttribute("value");
	}

	public void setAccountNo(String accountNo) {
		this.accountNo.sendKeys(accountNo);;
	}

	public String getAccountBalance() {
		return accountBalance.getAttribute("value");
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance.sendKeys(accountBalance);;
	}
	public void onClick() {
		submit.click();
	}

}
