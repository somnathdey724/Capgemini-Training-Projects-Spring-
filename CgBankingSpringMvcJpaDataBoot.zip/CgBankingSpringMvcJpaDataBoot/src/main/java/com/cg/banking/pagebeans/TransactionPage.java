package com.cg.banking.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TransactionPage {
	@FindBy(how=How.NAME,name="accountNo")
	private WebElement accountNo;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	@FindBy(how=How.XPATH,xpath="/html/body/div")
	private WebElement actualErrorMessage;
	
	public TransactionPage() {}

	public String getAccountNo() {
		return accountNo.getAttribute("value");
	}

	public void setAccountNo(String accountNo) {
		this.accountNo.sendKeys(accountNo);
	}
	public String getActualErrorMessage() {
		return actualErrorMessage.getAttribute("value");
	}
	public void onClick() {
		submit.click();
	}
}
