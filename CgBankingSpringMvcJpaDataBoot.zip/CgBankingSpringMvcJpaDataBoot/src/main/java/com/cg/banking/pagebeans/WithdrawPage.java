package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class WithdrawPage {
	@FindBy(how=How.NAME,name="accountNo")
	private WebElement accountNumber;
	@FindBy(how=How.NAME,name="pinNumber")
	private WebElement pinNumber;
	@FindBy(how=How.NAME,name="accountBalance")
	private WebElement accountBalance;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;

	public WithdrawPage() {}

	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber.sendKeys(accountNumber);;
	}

	public String getPinNumber() {
		return pinNumber.getAttribute("value");
	}

	public void setPinNumber(String pinNumber) {
		this.pinNumber.sendKeys(pinNumber);;
	}

	public String getAccountBalance() {
		return accountBalance.getAttribute("value");
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance.sendKeys(accountBalance);
	}
	public void onClick() {
		submit.click();
	}
}
