package com.cg.banking.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.AccountDetailsPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AccountDetailsStepDefination {
	WebDriver driver;
	AccountDetailsPage accountDetailsPage;
	@Given("^User view his Banking Account Details Page$")
	public void user_view_his_Banking_Account_Details_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/accountDetails");
		accountDetailsPage=PageFactory.initElements(driver, AccountDetailsPage.class);
	}

	@When("^User enter correct 'accountNumber'$")
	public void user_enter_correct_accountNumber() throws Throwable {
	    accountDetailsPage.setAccountNo("1");
	    accountDetailsPage.onClick();
	}

	@Then("^User gets all details of the 'accountDetails' page$")
	public void user_gets_all_details_of_the_accountDetails_page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Account Details";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@Given("^User unable to view his Banking Account Details Page$")
	public void user_unable_to_view_his_Banking_Account_Details_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/accountDetails");
		accountDetailsPage=PageFactory.initElements(driver, AccountDetailsPage.class);
	}

	@When("^User enter incorrect 'accountNumber'$")
	public void user_enter_incorrect_accountNumber() throws Throwable {
		accountDetailsPage.setAccountNo("1111");
	    accountDetailsPage.onClick();
	}

	@Then("^user gets 'Account detail Page' with error message$")
	public void user_gets_Account_detail_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="AccountDetailPage";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
