package com.cg.banking.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.AllAccountDetailsPage;
import com.cg.banking.pagebeans.FundTransferPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AllAccountDetailsStepDefination {
WebDriver driver;
AllAccountDetailsPage allAccountDetailsPage;
@Given("^User is on Banking IndexPage$")
public void user_is_on_Banking_IndexPage() throws Throwable {
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://localhost:2112/fundTransfer");
	allAccountDetailsPage=PageFactory.initElements(driver, AllAccountDetailsPage.class);
}

@When("^User clicks on 'All Account details' button$")
public void user_clicks_on_All_Account_details_button() throws Throwable {
    allAccountDetailsPage.onClick();
}

@Then("^User is on 'All Account details Page'$")
public void user_is_on_All_Account_details_Page() throws Throwable {
	String actualTitle = driver.getTitle();
	String expectedTitle="AllAccount Details";
	Assert.assertEquals(actualTitle, expectedTitle);
	driver.close();
}


}
