package com.cg.banking.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.FundTransferPage;
import com.cg.banking.pagebeans.OpenAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FundTransferStepDefination {
	WebDriver driver;
	FundTransferPage fundTransferPage;
	@Given("^User is on Banking Fund Transfer Page$")
	public void user_is_on_Banking_Fund_Transfer_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/fundTransfer");
		fundTransferPage=PageFactory.initElements(driver, FundTransferPage.class);
	}

	@When("^User enters correct values for accountNumberTo accountNumberFrom pinNumber transferAmount$")
	public void user_enters_correct_values_for_accountNumberTo_accountNumberFrom_pinNumber_transferAmount() throws Throwable {
	    fundTransferPage.setAccountNoTo("1");
	    fundTransferPage.setAccountNoFrom("2");
	    fundTransferPage.setTransferAmount("1000");
	    fundTransferPage.setPinNumber("0111");
	    fundTransferPage.onClick();
	}

	@Then("^User gets the amount transferred in 'Fund Transfer successful' Page$")
	public void user_gets_the_amount_transferred_in_Fund_Transfer_successful_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Transfer Successful";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@Given("^User is on Banking  Fund Transfer Page$")
	public void user_is_on_Banking_Fund_Transfer_Page1() throws Throwable {
	 		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/fundTransfer");
		fundTransferPage=PageFactory.initElements(driver, FundTransferPage.class);
	}

	@When("^User enters incorrect accountNumberTo and correct accountNumberFrom transferAmount and pinNumber$")
	public void user_enters_incorrect_accountNumberTo_and_correct_accountNumberFrom_transferAmount_and_pinNumber() throws Throwable {
		  fundTransferPage.setAccountNoTo("1111");
		    fundTransferPage.setAccountNoFrom("2");
		    fundTransferPage.setTransferAmount("1000");
		    fundTransferPage.setPinNumber("0111");
		    fundTransferPage.onClick();
	}

	@Then("^User is on 'Fund Transfer' page with error message$")
	public void user_is_on_Fund_Transfer_page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Fund Transfer";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect  accountNumberFrom and correct accountNumberTo transferAmount and pinNumber$")
	public void user_enters_incorrect_accountNumberFrom_and_correct_accountNumberTo_transferAmount_and_pinNumber() throws Throwable {
		  fundTransferPage.setAccountNoTo("1");
		    fundTransferPage.setAccountNoFrom("21111");
		    fundTransferPage.setTransferAmount("1000");
		    fundTransferPage.setPinNumber("0111");
		    fundTransferPage.onClick();
	}

	@When("^User enters incorrect  pinNumber and correct accountNumberTo transferAmount and accountNumberFrom$")
	public void user_enters_incorrect_pinNumber_and_correct_accountNumberTo_transferAmount_and_accountNumberFrom() throws Throwable {
		  fundTransferPage.setAccountNoTo("1");
		    fundTransferPage.setAccountNoFrom("2");
		    fundTransferPage.setTransferAmount("1000");
		    fundTransferPage.setPinNumber("0123");
		    fundTransferPage.onClick();
	}

	@When("^User enters incorrect  transferAmount and correct accountNumberTo pinNumber and accountNumberFrom$")
	public void user_enters_incorrect_transferAmount_and_correct_accountNumberTo_pinNumber_and_accountNumberFrom() throws Throwable {
		  fundTransferPage.setAccountNoTo("1");
		    fundTransferPage.setAccountNoFrom("2");
		    fundTransferPage.setTransferAmount("100000000");
		    fundTransferPage.setPinNumber("0111");
		    fundTransferPage.onClick();
	}

}
