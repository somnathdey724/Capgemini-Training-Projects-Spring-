package com.cg.banking.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.OpenAccountPage;
import com.cg.banking.pagebeans.WithdrawPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WithdrawStepDefination {
	WebDriver driver;
	WithdrawPage withdrawPage;
	@Given("^User is on Banking Withdraw Page$")
	public void user_is_on_Banking_Withdraw_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/withdrawPage");
		withdrawPage=PageFactory.initElements(driver, WithdrawPage.class);
	}

	@When("^User enters correct values for accountNumber pinNumber accountbalance$")
	public void user_enters_correct_values_for_accountNumber_pinNumber_accountbalance() throws Throwable {
	    withdrawPage.setAccountNumber("1");
	    withdrawPage.setAccountBalance("1000");
	    withdrawPage.setPinNumber("0123");
	    withdrawPage.onClick();
	}

	@Then("^User gets his current bank balance in 'Withraw Successful' Page$")
	public void user_gets_his_current_bank_balance_in_Withraw_Successful_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Withdraw Successful";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect accountNumber and correct pinNumber and accountbalance$")
	public void user_enters_incorrect_accountNumber_and_correct_pinNumber_and_accountbalance() throws Throwable {
		withdrawPage.setAccountNumber("1111");
	    withdrawPage.setAccountBalance("1000");
	    withdrawPage.setPinNumber("0123");
	    withdrawPage.onClick();
	}

	@Then("^User is on 'Withdraw Page' with error message$")
	public void user_is_on_Withdraw_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Withdraw Page";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect pinNumber and correct accountNo and accountbalance$")
	public void user_enters_incorrect_pinNumber_and_correct_accountNo_and_accountbalance() throws Throwable {
		withdrawPage.setAccountNumber("1");
	    withdrawPage.setAccountBalance("1000");
	    withdrawPage.setPinNumber("0111");
	    withdrawPage.onClick();
	}

	@When("^User enters incorrect accountbalance and correct accountNo and pinNumber$")
	public void user_enters_incorrect_accountbalance_and_correct_accountNo_and_pinNumber() throws Throwable {
		withdrawPage.setAccountNumber("1");
	    withdrawPage.setAccountBalance("10000000000000");
	    withdrawPage.setPinNumber("0123");
	    withdrawPage.onClick();
	}
}
