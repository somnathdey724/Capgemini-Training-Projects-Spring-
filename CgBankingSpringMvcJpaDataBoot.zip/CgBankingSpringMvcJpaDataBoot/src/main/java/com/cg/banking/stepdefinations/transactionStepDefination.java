package com.cg.banking.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.TransactionPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class transactionStepDefination {
	WebDriver driver;
	TransactionPage transactionPage;
	@Given("^User is on Transaction Page$")
	public void user_is_on_Transaction_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:2112/accountDetails");
		transactionPage=PageFactory.initElements(driver, TransactionPage.class);
	}

	@When("^User enters correct 'accountNumber'$")
	public void user_enters_correct_accountNumber() throws Throwable {
	   transactionPage.setAccountNo("1");
	   transactionPage.onClick();
	}

	@Then("^User gets all details of the 'Transaction' page$")
	public void user_gets_all_details_of_the_Transaction_page() throws Throwable {
		String actualTitle = driver.getTitle();
		System.out.println(actualTitle);
		String expectedTitle="Account Details";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect 'accountNumber'$")
	public void user_enters_incorrect_accountNumber() throws Throwable {
		   transactionPage.setAccountNo("1111");
		   transactionPage.onClick();
	}

	@Then("^user gets 'Transaction Page' with error message$")
	public void user_gets_Transaction_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		System.out.println(actualTitle);
		String expectedTitle="AccountDetailPage";
		System.out.println(transactionPage.getActualErrorMessage());
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
