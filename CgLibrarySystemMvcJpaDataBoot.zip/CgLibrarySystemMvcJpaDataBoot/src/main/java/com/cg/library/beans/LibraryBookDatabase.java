package com.cg.library.beans;

public class LibraryBookDatabase {
	private int libarayBookID;
	private Student student;
	private Book book;
	//private String issueDate;
	//private String returnDate;
}
