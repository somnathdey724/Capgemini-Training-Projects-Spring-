package com.cg.library.exception;

public class NoBooksIssuedException extends Exception {

	public NoBooksIssuedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoBooksIssuedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoBooksIssuedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoBooksIssuedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoBooksIssuedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
