package com.cg.payroll.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.AssociateDetailsPage;
import com.cg.payroll.pagebeans.CalculateSalaryPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AssociateDetailsStepDefination {
	WebDriver driver;
	AssociateDetailsPage associateDetailsPage;
	@Given("^User is on Enter Associate Details Page$")
	public void user_is_on_Enter_Associate_Details_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:1278/getAssociateDetails");
		associateDetailsPage=PageFactory.initElements(driver, AssociateDetailsPage.class); 
	}

	@When("^User enter the correct 'associateID'$")
	public void user_enter_the_correct_associateID() throws Throwable {
		associateDetailsPage.setAssociateId("1");
		associateDetailsPage.clickSignIn();
	}

	@Then("^User gets details in 'Associate Details' page$")
	public void user_gets_details_in_Associate_Details_page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="associate Details";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enters incorrect 'associateID'$")
	public void user_enters_incorrect_associateID() throws Throwable {
		associateDetailsPage.setAssociateId("11111");
		associateDetailsPage.clickSignIn();
	}

	@Then("^User gets error message in 'Associate ID Page'$")
	public void user_gets_error_message_in_Associate_ID_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
