package com.cg.payroll.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.CalculateSalaryPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculateSalaryStepDefination {
	WebDriver driver;
	CalculateSalaryPage calculateSalary;
	@Given("^User is on Capgemini IndexPage$")
	public void user_is_on_Capgemini_IndexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:1278/calculateNetSalary");
		calculateSalary=PageFactory.initElements(driver, CalculateSalaryPage.class);
	}

	@When("^User enter correct 'associateID'$")
	public void user_enter_correct_associateID() throws Throwable {
		  	/*By associateIDField=By.name("associateId");
		    WebElement associateId=driver.findElement(associateIDField);
		    associateId.sendKeys("1");
		    By sumbitField=By.name("submit");
		    WebElement submitButton= driver.findElement(sumbitField);
		    submitButton.click();*/
		calculateSalary.setAssociateId("1");
		calculateSalary.clickSignIn();
		
	}

	@Then("^User gets net salary in 'Net Salary' page$")
	public void user_gets_net_salary_in_Net_Salary_page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Net Salary";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

	@When("^User enter incorrect 'associateID'$")
	public void user_enter_incorrect_associateID() throws Throwable {
		/*	By associateIDField=By.name("associateId");
		    WebElement associateId=driver.findElement(associateIDField);
		    associateId.sendKeys("1111");
		    By sumbitField=By.name("submit");
		    WebElement submitButton= driver.findElement(sumbitField);
		    submitButton.click();*/
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:1278/calculateNetSalary");
		calculateSalary=PageFactory.initElements(driver, CalculateSalaryPage.class);
		calculateSalary.setAssociateId("11111");
		calculateSalary.clickSignIn();
	}

	@Then("^User gets 'Associate ID Page' with error message$")
	public void user_gets_Associate_ID_Page_with_error_message() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}
}
