package com.cg.payroll.client;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesimpl;

public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException, AssociateDetailsNotFound {
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) context.getBean("payrollServices");
		int associateId=payrollServices.acceptAssociateDetails("Somnath", "Dey", "som@gmail.com", "HR", "Sr An", "CBCJ23D", 15000, 18000, 2000, 2000, 3214564, "ICICI", "icici0004");
		//payrollServices.acceptAssociateDetails("Somnath", "Dey", "som@gmail.com", "HR", "Sr An", "CBCJ23D", 15000, 18000, 2000, 2000, 3214564, "ICICI", "icici0004");	
		//System.out.println(associateId);
		//System.out.println(payrollServices.calculateNetSalary(associateId));
		//System.out.println(payrollServices.getAssociateDetails(associateId));
		ArrayList<Associate> list=payrollServices.getAllAssociatesDetails();
		for (Associate associate : list) {
			System.out.println(associate);
		}
	}
}