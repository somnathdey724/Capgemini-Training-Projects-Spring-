package com.cg.payroll.client;
import java.util.ArrayList;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices= (PayrollServices) context.getBean("payrollServices");
		int associateId=payrollServices.acceptAssociateDetails("Somnath", "Dey", "som@gmail.com", "HR", "Sr. Analyst", "CBCJ45A", 59000, 17300, 0, 0, 12345,"bankName", "ifscCode");
		//payrollServices.acceptAssociateDetails("Somnath", "Dey", "som@gmail.com", "HR", "Sr. Analyst", "CBCJ45A", 59000, 17300, 0, 0, 12345,"bankName", "ifscCode");
		
		//System.out.println(associateID);
		//System.out.println(payrollServices.calculateNetSalary(associateId));
		//System.out.println(payrollServices.getAssociateDetails(associateId));
		ArrayList<Associate> list=payrollServices.getAllAssociatesDetails();
		for (Associate associate : list) {
			System.out.println(associate);
		}
	}
}