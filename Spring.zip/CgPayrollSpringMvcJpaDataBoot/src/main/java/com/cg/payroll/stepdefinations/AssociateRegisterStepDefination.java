package com.cg.payroll.stepdefinations;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.RegisterPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AssociateRegisterStepDefination {
	WebDriver driver;
	RegisterPage registerPage;
	@Given("^User is on Registration Page$")
	public void user_is_on_Registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:1278/register");
		registerPage=PageFactory.initElements(driver, RegisterPage.class);
	}

	@When("^User enter correct credentials$")
	public void user_enter_correct_credentials() throws Throwable {
	/*    By firstNameField=By.name("firstName");
	    WebElement firstName=driver.findElement(firstNameField);
	    firstName.sendKeys("Somnath");
	    By lastNameField=By.name("lastName");
	    WebElement lastName=driver.findElement(lastNameField);
	    lastName.sendKeys("Dey");
	    By departmentField=By.name("department");
	    WebElement department=driver.findElement(departmentField);
	    department.sendKeys("HR");
	    By designationField=By.name("designation");
	    WebElement designation=driver.findElement(designationField);
	    designation.sendKeys("Sr. Analyst");
	    By pancardField=By.name("pancard");
	    WebElement pancard=driver.findElement(pancardField);
	    pancard.sendKeys("CBCF12SD");
	    By emailIdField=By.name("emailId");
	    WebElement emailId=driver.findElement(emailIdField);
	    emailId.sendKeys("somnathdey724@gmail.com");
	    By yearlyInvestmentUnder80cField=By.name("yearlyInvestmentUnder80c");
	    WebElement yearlyInvestmentUnder80c=driver.findElement(yearlyInvestmentUnder80cField);
	    yearlyInvestmentUnder80c.sendKeys("15000");
	    By accountNumberField=By.name("bankDetails.accountNumber");
	    WebElement accountNumber=driver.findElement(accountNumberField);
	    accountNumber.sendKeys("321456");
	    By bankNameField=By.name("bankDetails.bankName");
	    WebElement bankName=driver.findElement(bankNameField);
	    bankName.sendKeys("ICICI");
	    By ifscCodeField=By.name("bankDetails.ifscCode");
	    WebElement ifscCode=driver.findElement(ifscCodeField);
	    ifscCode.sendKeys("ICICI00028");
	    By basicSalaryField=By.name("salary.basicSalary");
	    WebElement basicSalary=driver.findElement(basicSalaryField);
	    basicSalary.sendKeys("17000");
	    By sumbitField=By.name("submit");
	    WebElement submitButton= driver.findElement(sumbitField);
	    submitButton.click();*/
		registerPage.setFirstName("Somnath");
		registerPage.setLastName("Dey");
		registerPage.setDepartment("HR");
		registerPage.setDesignation("Sr. Analyst");
		registerPage.setPancard("CBCJ12SX");
		registerPage.setEmailId("somnathdey724@gmail.com");
		registerPage.setYearlyInvestmentUnder80c("15000");
		registerPage.setAccountNumber("12345");
		registerPage.setBankName("SBI");
		registerPage.setBankCode("SBIN000285");
		registerPage.setBasicSalary("15000");
		registerPage.clickSignIn();
	}

	@Then("^User get the AssociateID in Registration Success Page$")
	public void user_get_the_AssociateID_in_Registration_Success_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}

/*	@When("^User enter incorrect credentials$")
	public void user_enter_incorrect_credentials() throws Throwable {
	    By firstNameField=By.name("firstName");
	    WebElement firstName=driver.findElement(firstNameField);
	    firstName.sendKeys("");
	    By lastNameField=By.name("lastName");
	    WebElement lastName=driver.findElement(lastNameField);
	    lastName.sendKeys("Dey");
	    By departmentField=By.name("department");
	    WebElement department=driver.findElement(departmentField);
	    department.sendKeys("HR");
	    By designationField=By.name("designation");
	    WebElement designation=driver.findElement(designationField);
	    designation.sendKeys("Sr. Analyst");
	    By pancardField=By.name("pancard");
	    WebElement pancard=driver.findElement(pancardField);
	    pancard.sendKeys("CBCF12SD");
	    By emailIdField=By.name("emailId");
	    WebElement emailId=driver.findElement(emailIdField);
	    emailId.sendKeys("somnathdey724@gmail.com");
	    By yearlyInvestmentUnder80cField=By.name("yearlyInvestmentUnder80c");
	    WebElement yearlyInvestmentUnder80c=driver.findElement(yearlyInvestmentUnder80cField);
	    yearlyInvestmentUnder80c.sendKeys("15000");
	    By accountNumberField=By.name("bankDetails.accountNumber");
	    WebElement accountNumber=driver.findElement(accountNumberField);
	    accountNumber.sendKeys("321456");
	    By bankNameField=By.name("bankDetails.bankName");
	    WebElement bankName=driver.findElement(bankNameField);
	    bankName.sendKeys("ICICI");
	    By ifscCodeField=By.name("bankDetails.ifscCode");
	    WebElement ifscCode=driver.findElement(ifscCodeField);
	    ifscCode.sendKeys("ICICI00028");
	    By basicSalaryField=By.name("salary.basicSalary");
	    WebElement basicSalary=driver.findElement(basicSalaryField);
	    basicSalary.sendKeys("17000");
	    By sumbitField=By.name("submit");
	    WebElement submitButton= driver.findElement(sumbitField);
	    submitButton.click();
		registerPage.setFirstName("");
		registerPage.setLastName("Dey");
		registerPage.setDepartment("HR");
		registerPage.setDesignation("Sr. Analyst");
		registerPage.setPancard("CBCJ12SX");
		registerPage.setEmailId("somnathdey724@gmail.com");
		registerPage.setYearlyInvestmentUnder80c("15000");
		registerPage.setAccountNumber("12345");
		registerPage.setBankName("SBI");
		registerPage.setBankCode("SBIN000285");
		registerPage.setBasicSalary("15000");
		registerPage.clickSignIn();
	}

	@Then("^User gets the error message in Registration Page$")
	public void user_gets_the_error_message_in_Registration_Page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(actualTitle, expectedTitle);
		driver.close();
	}*/

}
