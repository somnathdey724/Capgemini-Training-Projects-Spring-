package com.cg.project.beans;
public class Employee {
	private int employeeId,basicSalary;
	private String firstName,lastName;
	private Address address;
	public Employee() {
		}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", basicSalary=" + basicSalary + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address=" + address + "]";
	}
	public Employee(int employeeId, int basicSalary, String firstName, String lastName, Address address) {
		super();
		this.employeeId = employeeId;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}
	
}
